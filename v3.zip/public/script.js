document.getElementById("sensorForm").addEventListener("submit", async function(event) {
    event.preventDefault();

    const date = document.getElementById("date").value;
    const temperature = document.getElementById("temperature").value;
    const humidity = document.getElementById("humidity").value;
    const pressure = document.getElementById("pressure").value;

    const data = {
        date: new Date(date), // Convert to JavaScript Date object
        temperature: parseFloat(temperature),
        humidity: parseFloat(humidity),
        pressure: parseFloat(pressure),
    };

    try {
        const response = await fetch("/insert_data", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(data),
        });

        const messageElement = document.getElementById("message");

        if (response.ok) {
            messageElement.textContent = "Data inserted successfully!";
            messageElement.classList.add("success");
            messageElement.classList.remove("error");
        } else {
            messageElement.textContent = "Error inserting data!";
            messageElement.classList.add("error");
            messageElement.classList.remove("success");
        }
    } catch (error) {
        console.error("Error:", error);
        const messageElement = document.getElementById("message");
        messageElement.textContent = "Error communicating with the server!";
        messageElement.classList.add("error");
        messageElement.classList.remove("success");
    }
});
