const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const { MongoClient } = require('mongodb');
require('dotenv').config();

// Create Express app
const app = express();
const port = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// MongoDB connection setup
const mongoURI = process.env.MONGO_URI;
const dbName = process.env.DB_NAME;
const collectionName = process.env.COLLECTION_NAME;

const connectMongoDB = async () => {
  const client = new MongoClient(mongoURI);
  try {
    await client.connect();
    console.log("Connected to MongoDB");
    const db = client.db(dbName);
    return db.collection(collectionName);
  } catch (error) {
    console.error("Error connecting to MongoDB:", error);
    process.exit(1);
  }
};

// API endpoint to get sensor data
app.get('/api/data', async (req, res) => {
  try {
    const collection = await connectMongoDB();
    const data = await collection.find({}).sort({ timestamp: -1 }).toArray();
    res.json(data);
  } catch (err) {
    res.status(500).json({ message: "Error fetching data", error: err });
  }
});

// Start server
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
